#ifndef __U8G2_STM32_H__
#define __U8G2_STM32_H__

#include "main.h"
#include "u8g2.h"
#include "u8x8.h"

extern SPI_HandleTypeDef hspi1;

uint8_t u8x8_byte_stm32_hw_spi(
    u8x8_t *u8x8,
    uint8_t msg,
    uint8_t arg_int,
    void *arg_ptr);

uint8_t u8x8_gpio_and_delay_stm32(
    u8x8_t *u8x8,
    uint8_t msg,
    uint8_t arg_int,
    void *arg_ptr);

#endif
