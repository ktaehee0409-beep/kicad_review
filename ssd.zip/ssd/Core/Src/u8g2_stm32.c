#include "u8g2_stm32.h"

#define OLED_CS_PORT      GPIOC
#define OLED_CS_PIN       GPIO_PIN_0

#define OLED_DC_PORT      GPIOC
#define OLED_DC_PIN       GPIO_PIN_1

#define OLED_RES_PORT     GPIOC
#define OLED_RES_PIN      GPIO_PIN_2

uint8_t u8x8_byte_stm32_hw_spi(
    u8x8_t *u8x8,
    uint8_t msg,
    uint8_t arg_int,
    void *arg_ptr)
{
    static uint8_t buffer[32]; // 데이터를 모아서 한 번에 전송하여 속도 극대화
    static uint8_t buffer_index;

    switch (msg)
    {
        case U8X8_MSG_BYTE_INIT:
        {
            break;
        }

        case U8X8_MSG_BYTE_SEND:
        {
            uint8_t *data_ptr = (uint8_t *)arg_ptr;

            while (arg_int > 0)
            {
                buffer[buffer_index++] = *data_ptr++;
                arg_int--;

                if (buffer_index >= sizeof(buffer))
                {
                    HAL_SPI_Transmit(&hspi1, buffer, buffer_index, HAL_MAX_DELAY);
                    buffer_index = 0;
                }
            }
            break;
        }

        case U8X8_MSG_BYTE_SET_DC:
        {
            HAL_GPIO_WritePin(OLED_DC_PORT, OLED_DC_PIN, (GPIO_PinState)arg_int);
            break;
        }

        case U8X8_MSG_BYTE_START_TRANSFER:
        {
            buffer_index = 0;
            HAL_GPIO_WritePin(OLED_CS_PORT, OLED_CS_PIN, GPIO_PIN_RESET);
            break;
        }

        case U8X8_MSG_BYTE_END_TRANSFER:
        {
            if (buffer_index > 0)
            {
                HAL_SPI_Transmit(&hspi1, buffer, buffer_index, HAL_MAX_DELAY);
                buffer_index = 0;
            }
            HAL_GPIO_WritePin(OLED_CS_PORT, OLED_CS_PIN, GPIO_PIN_SET);
            break;
        }

        default:
            return 0;
    }
    return 1;
}

uint8_t u8x8_gpio_and_delay_stm32(
    u8x8_t *u8x8,
    uint8_t msg,
    uint8_t arg_int,
    void *arg_ptr)
{
    switch (msg)
    {
        case U8X8_MSG_GPIO_AND_DELAY_INIT:
        {
            HAL_Delay(1);
            break;
        }

        case U8X8_MSG_DELAY_MILLI:
        {
            HAL_Delay(arg_int);
            break;
        }

        case U8X8_MSG_DELAY_10MICRO:
        {
            for (volatile uint16_t i = 0; i < 100; i++) { __NOP(); }
            break;
        }

        case U8X8_MSG_DELAY_100NANO:
        {
            __NOP();
            break;
        }

        case U8X8_MSG_GPIO_CS:
        {
            HAL_GPIO_WritePin(OLED_CS_PORT, OLED_CS_PIN, (GPIO_PinState)arg_int);
            break;
        }

        case U8X8_MSG_GPIO_DC:
        {
            HAL_GPIO_WritePin(OLED_DC_PORT, OLED_DC_PIN, (GPIO_PinState)arg_int);
            break;
        }

        case U8X8_MSG_GPIO_RESET:
        {
            HAL_GPIO_WritePin(OLED_RES_PORT, OLED_RES_PIN, (GPIO_PinState)arg_int);
            break;
        }

        default:
            return 0;
    }
    return 1;
}
